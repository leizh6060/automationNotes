variable "pc_host" {
  description = "Prism Central IP address or FQDN"
  type        = string
}

variable "pc_username" {
  description = "Prism Central username"
  type        = string
  default     = "admin"
}

variable "pc_password" {
  description = "Prism Central password"
  type        = string
  sensitive   = true
}

variable "cluster_name" {
  description = "Name of the target Nutanix cluster"
  type        = string
}

variable "subnet_name" {
  description = "Name of the subnet to attach the VM's NIC to"
  type        = string
}

variable "image_name" {
  description = "Name of the source image to clone the VM's boot disk from"
  type        = string
}

variable "vm_name" {
  description = "Name to give the provisioned VM"
  type        = string
  default     = "app-server-01"
}

variable "num_sockets" {
  description = "Number of vCPU sockets"
  type        = number
  default     = 2
}

variable "num_cores_per_socket" {
  description = "Number of cores per vCPU socket"
  type        = number
  default     = 1
}

variable "memory_gib" {
  description = "Memory size in GiB"
  type        = number
  default     = 4
}
