terraform {
  required_providers {
    nutanix = {
      source  = "nutanix/nutanix"
      version = ">= 2.4.0"
    }
  }
}

provider "nutanix" {
  endpoint = var.pc_host
  username = var.pc_username
  password = var.pc_password
  insecure = false
}

# --- Look up the cluster, subnet, and image by name ---

data "nutanix_clusters_v2" "clusters" {}

locals {
  cluster_ext_id = one([
    for c in data.nutanix_clusters_v2.clusters.cluster_entities :
    c.ext_id if c.name == var.cluster_name
  ])
}

data "nutanix_subnets_v2" "subnets" {}

locals {
  subnet_ext_id = one([
    for s in data.nutanix_subnets_v2.subnets.subnets :
    s.ext_id if s.name == var.subnet_name
  ])
}

data "nutanix_images_v2" "images" {}

locals {
  image_ext_id = one([
    for i in data.nutanix_images_v2.images.images :
    i.ext_id if i.name == var.image_name
  ])
}

# --- Provision the VM ---

resource "nutanix_virtual_machine_v2" "app_server" {
  name                 = var.vm_name
  description          = "Provisioned via Terraform"
  num_sockets          = var.num_sockets
  num_cores_per_socket = var.num_cores_per_socket
  memory_size_bytes    = var.memory_gib * 1024 * 1024 * 1024

  cluster {
    ext_id = local.cluster_ext_id
  }

  disks {
    disk_address {
      bus_type = "SCSI"
      index    = 0
    }
    backing_info {
      vm_disk {
        data_source {
          reference {
            image_reference {
              image_ext_id = local.image_ext_id
            }
          }
        }
      }
    }
  }

  nics {
    network_info {
      nic_type  = "NORMAL_NIC"
      vlan_mode = "ACCESS"
      subnet {
        ext_id = local.subnet_ext_id
      }
    }
  }

  boot_config {
    legacy_boot {
      boot_order = ["DISK", "CDROM", "NETWORK"]
    }
  }

  power_state = "ON"
}
