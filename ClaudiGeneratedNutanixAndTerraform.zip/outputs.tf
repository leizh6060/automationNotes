output "vm_ext_id" {
  description = "The ext_id (UUID) of the provisioned VM"
  value       = nutanix_virtual_machine_v2.app_server.ext_id
}
